package com.cg.emp.controllers;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;





import com.cg.emp.entities.Employee;
import com.cg.emp.exceptions.EmployeeException;
import com.cg.emp.services.IEmployeeService;

@Controller
public class EmployeeController {

	private IEmployeeService services;
	private List<String> designations;


	@PostConstruct
	public void initialize()
	{
		designations=new ArrayList<String>();	     //used to show dropdown on add form
		designations.add("Software Engineer");
		designations.add("Senior Software Engineer");
		designations.add("Team Lead");
		designations.add("Manager");
	
	}
	//Injecting the service object to controller 
	@Resource(name="employeeService")
	public void setServices(IEmployeeService services) {
		this.services = services;
	}
	
	//redirect to welcome page
	@RequestMapping("/welcome.do")
	public ModelAndView welocmePage()
	{
		ModelAndView model=new ModelAndView();
		model.setViewName("welcome");
		return model;
	}
	
	//redirect to add form page
	@RequestMapping("/add.do")
	public ModelAndView addForm()
	{
		ModelAndView model=new ModelAndView();
		model.setViewName("insertForm");
		model.addObject("employee",new Employee());	 // object of employee passed to  the add's form
		model.addObject("designation", designations);
		return model;
		
	}
	//taking data from add form page and redirect to success page after successful insertion
	
	@RequestMapping("insertionSubmit.do")
	public ModelAndView addFormSubmit(@ModelAttribute("employee") @Valid Employee empl, BindingResult result) throws EmployeeException
	{
		ModelAndView model=new ModelAndView();
		if(result.hasErrors())
		{
			model.setViewName("insertForm");
			model.addObject("designation",designations);
					return model;
		}
		
		try {
			Employee employee=services.addEmployee(empl);
			model.setViewName("successInsert");
			model.addObject("employee", employee);
			return model;
		} catch (EmployeeException e) {
			
			model.setViewName("error");
			model.addObject("errormsg", "Check your details");
			model.addObject("exceptions", e.getMessage());
			return model;

			
		}
	}
	
	//redirect to show all page and showing all details of employee
	
	@RequestMapping("show.do")
	public ModelAndView showDetails()
	{
		ModelAndView model=new ModelAndView();
		try {
			List<Employee> empList=services.showAllEmployee();
			model.setViewName("showAll");
			model.addObject("empAll", empList);
			return model;
		} catch (EmployeeException e) {
			model.setViewName("error");
			model.addObject("errormsg", "Check your details");
			model.addObject("exceptions", e.getMessage());
			return model;
		}
		
	}
	
}
