package com.cg.emp.services;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.cg.emp.dao.IEmployeeDao;
import com.cg.emp.entities.Employee;
import com.cg.emp.exceptions.EmployeeException;

@Service("employeeService")
public class EmployeeServiceImpl implements IEmployeeService {
	
	private IEmployeeDao dao;
	
	@Resource(name="employeeDao")
	public void setDao(IEmployeeDao dao) {
		this.dao = dao;
	}

	//Start Of Insertion Method
	@Override
	public Employee addEmployee(Employee employee) throws EmployeeException {
		try {
			Employee empl=dao.addEmployee(employee);
			
			if(empl==null)
			{
				return null;
			}
			else
			{
			return empl;
			}
		} catch (EmployeeException e) {
			throw new EmployeeException("Insertion Can't Be Done On Database!!!!!");
		}
		
	}//End of Insertion Method

	//Start Of Show All Method
	@Override
	public List<Employee> showAllEmployee() throws EmployeeException {
		
		try {
			List<Employee> empList=dao.showAllEmployee();
			if(empList==null)
			{
				return null;
			}
			else
			{
				return empList;
			}
		} catch (EmployeeException e) {
			throw new EmployeeException("Data Can't Be Retrieved From Database!!!!");	
		}
		
	}//End of Show All Method

}
