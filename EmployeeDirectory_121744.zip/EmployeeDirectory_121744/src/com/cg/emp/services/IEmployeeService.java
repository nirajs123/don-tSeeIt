package com.cg.emp.services;

import java.util.List;

import com.cg.emp.entities.Employee;
import com.cg.emp.exceptions.EmployeeException;

public interface IEmployeeService {
	Employee addEmployee(Employee employee) throws EmployeeException;
	List<Employee> showAllEmployee() throws EmployeeException;

}
