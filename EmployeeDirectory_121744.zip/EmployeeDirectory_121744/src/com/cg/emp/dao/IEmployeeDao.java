package com.cg.emp.dao;

import java.util.List;

import com.cg.emp.entities.Employee;
import com.cg.emp.exceptions.EmployeeException;

public interface IEmployeeDao {

	
	Employee addEmployee(Employee employee) throws EmployeeException;
	List<Employee> showAllEmployee() throws EmployeeException;
}
