package com.cg.emp.dao;

import java.util.List;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;
import javax.persistence.RollbackException;




import org.springframework.stereotype.Repository;

import com.cg.emp.entities.Employee;
import com.cg.emp.exceptions.EmployeeException;

@Repository("employeeDao")
public class EmployeeDaoImpl implements IEmployeeDao {

	private EntityManagerFactory factory;
	
	@Resource(name="entityManagerFactory")
	public void setFactory(EntityManagerFactory factory) {
		this.factory = factory;
	}

	//Start Of Insertion Method
	@Override
	public Employee addEmployee(Employee employee) throws EmployeeException {
		
		try {
			EntityManager manager=factory.createEntityManager();
			manager.getTransaction().begin();
			manager.persist(employee);
			manager.getTransaction().commit();
			return employee;
		} catch (RollbackException e) {
			throw new EmployeeException("Insertion Of Employee Failed",e);
		}
	}//End of Insertion Method

	
	//Start Of Show All method
	@Override
	@SuppressWarnings("unchecked")
	public List<Employee> showAllEmployee() throws EmployeeException {
		String qryStr="select e from employee e";
		EntityManager manager=factory.createEntityManager();
		Query qry=manager.createQuery(qryStr, Employee.class);
		List<Employee> empList= qry.getResultList();
		
		if(empList==null)
		{
			throw new EmployeeException("Your Records Not Retrieved From Database!!!!");		
		}
		else
		{
			System.out.println("Your All Records Is Fetched From Database");
			return empList;
		}
		
	}//End of Show All Method

}
