package com.cg.emp.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.beans.factory.annotation.Required;

import com.sun.istack.internal.NotNull;

@Entity(name="employee")
@Table(name="EMPLOYEE")
@SequenceGenerator(name="employee_generate", sequenceName="HIBERNATE_SEQUENCE", allocationSize=1 ,initialValue=1001)
public class Employee {
	
private int employeeId;
private String employeeName;
private String employeeGender;
private String employeeDesignation;
private String employeeEmail;
private String employeePhoneNumber;

@Id
@Column(name="EMPLOYEE_CODE")
@GeneratedValue(generator="employee_generate",strategy=GenerationType.SEQUENCE)
public int getEmployeeId() {
	return employeeId;
}
public void setEmployeeId(int employeeId) {
	this.employeeId = employeeId;
}

@Column(name="EMPLOYEE_NAME")
@NotEmpty(message="Employee Name Should Not Be Empty")
@Pattern(regexp = "^[a-zA-Z]+$", message = "Employee name must contain only characters or alphabets")
@Size(max=40,message="Employee Name Should be of 40 Characters")
public String getEmployeeName() {
	return employeeName;
}
public void setEmployeeName(String employeeName) {
	this.employeeName = employeeName;
}

@Column(name="EMPLOYEE_GENDER")
@Required
@NotNull
public String getEmployeeGender() {
	return employeeGender;
}
public void setEmployeeGender(String employeeGender) {
	this.employeeGender = employeeGender;
}
@Column(name="DESIGNATION_NAME")
@Required
@NotNull
public String getEmployeeDesignation() {
	return employeeDesignation;
}
public void setEmployeeDesignation(String employeeDesignation) {
	this.employeeDesignation = employeeDesignation;
}
@Column(name="EMPLOYEE_EMAIL")
@Email(message="Enter Valid Email")
public String getEmployeeEmail() {
	return employeeEmail;
}
public void setEmployeeEmail(String employeeEmail) {
	this.employeeEmail = employeeEmail;
}
@Column(name="EMPLOYEE_PHONE")
@Size(max=10,message="Phone Number Should Accept Only 10 digits")
@Pattern(regexp = "^[0-9]+$", message = "Phone Number should contain only digits")
public String getEmployeePhoneNumber() {
	return employeePhoneNumber;
}
public void setEmployeePhoneNumber(String employeePhoneNumber) {
	this.employeePhoneNumber = employeePhoneNumber;
}

@Override
public String toString() {
	return "Employee [employeeId=" + employeeId + ", employeeName="
			+ employeeName + ", employeeGender=" + employeeGender
			+ ", employeeDesignation=" + employeeDesignation
			+ ", employeeEmail=" + employeeEmail + ", employeePhoneNumber="
			+ employeePhoneNumber + "]";
}



}
