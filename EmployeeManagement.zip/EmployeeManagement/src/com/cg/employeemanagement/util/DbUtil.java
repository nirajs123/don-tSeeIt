package com.cg.employeemanagement.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.cg.employeemanagement.exceptions.EmployeeException;



public class DbUtil {

	public static Connection obtainConnection() throws EmployeeException
	{
		Connection conn=null;
		try {
			Context ctx = new InitialContext();  //Get Reference To Remote JNDI// it is naming api searching for default path of jndi 
			DataSource datasource =(DataSource) ctx.lookup("java:/OracleDS");
			conn=datasource.getConnection();
			System.out.println("Connceted");
 		} catch (NamingException e) {
			// TODO Auto-generated catch block
	
			throw new EmployeeException("Failed To Get JNDI Context",e);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Not Connected Properly"+e);
		}
		return conn;
		
	}
}
