package com.cg.employeemanagement.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;




import com.cg.employeemanagement.dto.Employee;
import com.cg.employeemanagement.exceptions.EmployeeException;
import com.cg.employeemanagement.services.EmployeeServiceimpl;
import com.cg.employeemanagement.services.IEmployeeService;


@WebServlet("*.do")
public class EmployeeController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    IEmployeeService services;
    

	
	public void init(ServletConfig config) throws ServletException {
		services=new EmployeeServiceimpl();
	}

	
	private void processRequest(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException, EmployeeException{
		String path=request.getServletPath();
		System.out.println(path);
		if(path.equals("/empl.do"))
		{
		RequestDispatcher dispatch=request.getRequestDispatcher("addEmployee.jsp");
		dispatch.forward(request, response);
		}
		if(path.equals("/empadd.do"))
		{
			Employee emp=new Employee();
			String name=request.getParameter("jname");
			String qual=request.getParameter("jqual");
			String sal=request.getParameter("jsal");
			emp.setEmpName(name);
			emp.setEmpQualification(qual);
			emp.setEmpSalary(Double.parseDouble(sal));
			try {
				int empId=services.addEmployee(emp);
				System.out.println(empId);
				request.setAttribute("empid", empId);
				RequestDispatcher req=request.getRequestDispatcher("welcome.jsp");
				req.forward(request, response);
			} catch (EmployeeException e) {
				// TODO Auto-generated catch block
				throw new EmployeeException("Insertion method not called");
			}
		}
		if(path.equals("/showall.do"))
		{
			List<Employee> emplist=services.showAll();
			System.out.println(emplist);
			request.setAttribute("data", emplist);
			RequestDispatcher req=request.getRequestDispatcher("showall.jsp");
			req.forward(request, response);
		}
		if(path.equals("/update.do"))
		{
			
			String id=request.getQueryString();
			String empId=id.substring(3,7);
			int eid=Integer.parseInt(empId);
			Employee e=services.updateEmp(eid);
			request.setAttribute("empdata", e);
			RequestDispatcher req=request.getRequestDispatcher("update.jsp");
			req.forward(request, response);
		}
		
		if(path.equals("/updatedata.do"))
		{
		 String id=request.getParameter("id");
		 int eid=Integer.parseInt(id);
		 String name=request.getParameter("name");
		 String qual=request.getParameter("qual");
		 String sal=request.getParameter("sal");
		 double esal=Double.parseDouble(sal);
		
		 Employee e=new Employee(eid,name,qual,esal);
		 e=services.updatEmployee(e);
		 System.out.println(e);
		 request.setAttribute("newdata",e);
		 
		 
		}
		if(path.equals("/delete.do"))
		{
			System.out.println("hiii");
			 String id=request.getQueryString();
			 String empId=id.substring(3,7);
			 int eid=Integer.parseInt(empId);
			 System.out.println(eid);
			 boolean delete=services.deleteEmployee(eid);
			 if(delete==true)
			 {
				 System.out.println("Data is Deleted");
				 RequestDispatcher req=request.getRequestDispatcher("updatedata.jsp");
				 req.forward(request, response);
			 }
			 else{
				 throw new EmployeeException("data is not able to update");
			 }
					 
		}
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			processRequest(request,response);
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			processRequest(request,response);
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void destroy() {
		services=null;
	}


}
