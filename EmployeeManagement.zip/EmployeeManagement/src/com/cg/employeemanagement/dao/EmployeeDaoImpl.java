package com.cg.employeemanagement.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.employeemanagement.dto.Employee;
import com.cg.employeemanagement.exceptions.EmployeeException;
import com.cg.employeemanagement.util.DbUtil;

public class EmployeeDaoImpl implements IEmployeedao {

	@Override
	public int addEmployee(Employee emp) throws EmployeeException {
		Connection conn=null;
		PreparedStatement ps=null;
		int empId=getEmpId();
		int msg=0;
		try {
			conn=DbUtil.obtainConnection();
			ps=conn.prepareStatement("insert into employeemanagement values(?,?,?,?)");
			ps.setInt(1,empId);
			ps.setString(2, emp.getEmpName());
			ps.setString(3, emp.getEmpQualification());
			ps.setDouble(4, emp.getEmpSalary());
			
			int status= ps.executeUpdate();
			if(status==1)
			{
				msg=empId;
				System.out.println("record is inserted");
			}
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			throw new EmployeeException("Connection Not called");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
		throw new EmployeeException("Not Inserted");
		}
		finally
		{
			try {
				ps.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				throw new EmployeeException("Connection Not closing",e);
			}
		}
		return msg;
	}

	@Override
	public List<Employee> showAll() throws EmployeeException {
		Connection conn=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		String query="Select emp_id,emp_name,emp_qual,emp_sal from  employeemanagement";
		List<Employee> empList=new ArrayList<Employee>();
		
		
		try {
			conn=DbUtil.obtainConnection();
			ps=conn.prepareStatement(query);
			rs=ps.executeQuery();
			while(rs.next())
			{
				Employee emp = new Employee();
				emp.setEmpid(rs.getInt("emp_id"));
				emp.setEmpName(rs.getString("emp_name"));
				emp.setEmpQualification(rs.getString("emp_qual"));
				emp.setEmpSalary(rs.getDouble("emp_sal"));
				empList.add(emp);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Data No Showing Properly"+e);
			 throw new EmployeeException("Show all method not called in dao");
		}
		
		return empList;
	}
	
	public int getEmpId() throws EmployeeException{
		Connection conn=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		int empId=0;
		try {
			conn=DbUtil.obtainConnection();
			ps=conn.prepareStatement("Select emp_mgt_seq.nextval from dual");
			rs=ps.executeQuery();
			while(rs.next())
			{
				empId=rs.getInt(1);
			}
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			throw new EmployeeException("Method of connection not called");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
		System.out.println("Sequence not created"+e);
		}
		
		finally
		{
			try {
				rs.close();
				ps.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				throw new EmployeeException("Connection Not closing",e);
			}
		}
		return empId;
	}
	public Employee getEmp(int empId) throws EmployeeException{
		Connection conn=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		Employee emp = new Employee();
		String query="Select emp_id,emp_name,emp_qual,emp_sal from  employeemanagement where emp_id=?";
		
		try {
			conn=DbUtil.obtainConnection();
			ps=conn.prepareStatement(query);
			ps.setInt(1, empId);
			rs=ps.executeQuery();
			while(rs.next())
			{
				
				emp.setEmpid(rs.getInt("emp_id"));
				emp.setEmpName(rs.getString("emp_name"));
				emp.setEmpQualification(rs.getString("emp_qual"));
				emp.setEmpSalary(rs.getDouble("emp_sal"));
				
			}
			System.out.println(emp);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			System.out.println(e1);
		}
		
		return emp;
		
	}

	@Override
	public Employee updatEmp(Employee e) throws EmployeeException {
		
		Connection conn=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		String updateId="Update employeemanagement set emp_id=?,emp_name=?,emp_qual=?,emp_sal=? where emp_id=?";
	

			try {
				conn=DbUtil.obtainConnection();
				ps=conn.prepareStatement(updateId);
				ps.setInt(1, e.getEmpid());
				ps.setString(2, e.getEmpName());
				ps.setString(3,e.getEmpQualification());
				ps.setDouble(4, e.getEmpSalary());
				ps.setInt(5,e.getEmpid());
				int flag=ps.executeUpdate();
				if(flag==1)
				{
					System.out.println("Record is updated");
				}
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				System.out.println("Not Update"+e1);
			}
	
		
		
		return e;
	}

	@Override
	public boolean deleteEmployee(int empid) throws EmployeeException {
		Connection conn=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		String deleteEmp="delete employeemanagement where emp_id=?";
		try {
			conn=DbUtil.obtainConnection();
			ps=conn.prepareStatement(deleteEmp);
			ps.setInt(1, empid);
			int flag=ps.executeUpdate();
			if(flag==1)
			{
				System.out.println("Record is updated");
				return true;
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			System.out.println("Not Update"+e1);
		}
		return false;
	}
	
	
}
