package com.cg.employeemanagement.dao;

import java.util.List;

import com.cg.employeemanagement.dto.Employee;
import com.cg.employeemanagement.exceptions.EmployeeException;

public interface IEmployeedao {
	 public int addEmployee(Employee emp) throws EmployeeException;
	 public List<Employee> showAll() throws EmployeeException; 
	 public Employee getEmp(int empid) throws EmployeeException;
	 public Employee updatEmp(Employee e) throws EmployeeException;
	 public boolean deleteEmployee(int empid) throws EmployeeException;
}
