package com.cg.employeemanagement.services;

import java.util.List;

import com.cg.employeemanagement.dao.EmployeeDaoImpl;
import com.cg.employeemanagement.dao.IEmployeedao;
import com.cg.employeemanagement.dto.Employee;
import com.cg.employeemanagement.exceptions.EmployeeException;

public class EmployeeServiceimpl implements IEmployeeService {

	IEmployeedao dao;
	
	public EmployeeServiceimpl() {
	
		dao=new EmployeeDaoImpl();
	}

	@Override
	public int addEmployee(Employee emp) throws EmployeeException {
		// TODO Auto-generated method stub
		try {
			return dao.addEmployee(emp);
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			throw new EmployeeException("Not calling addemployee properly in service class");
		}
	}

	@Override
	public List<Employee> showAll() throws EmployeeException {
		try{
		return dao.showAll();
		}
		catch (EmployeeException e) {
			// TODO Auto-generated catch block
			throw new EmployeeException("Not calling showall properly in service class");
		}
	}

	@Override
	public Employee updateEmp(int empid) throws EmployeeException {
		return dao.getEmp(empid);
	}

	@Override
	public Employee updatEmployee(Employee e) throws EmployeeException {
		// TODO Auto-generated method stub
		return dao.updatEmp(e);
	}

	@Override
	public boolean deleteEmployee(int empid) throws EmployeeException {
	
		
		return dao.deleteEmployee(empid);
	}

}
