package com.cg.employeemanagement.dto;

public class Employee {

	private int empid;
	private String empName;
	private String empQualification;
	private double empSalary;
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Employee(int empid, String empName, String empQualification,
			double empSalary) {
		super();
		this.empid = empid;
		this.empName = empName;
		this.empQualification = empQualification;
		this.empSalary = empSalary;
	}
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getEmpQualification() {
		return empQualification;
	}
	public void setEmpQualification(String empQualification) {
		this.empQualification = empQualification;
	}
	public double getEmpSalary() {
		return empSalary;
	}
	public void setEmpSalary(double empSalary) {
		this.empSalary = empSalary;
	}
	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", empName=" + empName
				+ ", empQualification=" + empQualification + ", empSalary="
				+ empSalary + "]";
	}
	
	
	
}
